---
name: Radio Calico
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e4e2e1'
  on-surface: '#1b1c1c'
  on-surface-variant: '#554338'
  inverse-surface: '#303030'
  inverse-on-surface: '#f3f0ef'
  outline: '#887366'
  outline-variant: '#dbc1b3'
  surface-tint: '#974800'
  primary: '#974800'
  on-primary: '#ffffff'
  primary-container: '#f48c42'
  on-primary-container: '#632d00'
  inverse-primary: '#ffb689'
  secondary: '#605e5a'
  on-secondary: '#ffffff'
  secondary-container: '#e6e2dc'
  on-secondary-container: '#666460'
  tertiary: '#2a6767'
  on-tertiary: '#ffffff'
  tertiary-container: '#76b1b1'
  on-tertiary-container: '#004444'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbc7'
  primary-fixed-dim: '#ffb689'
  on-primary-fixed: '#311300'
  on-primary-fixed-variant: '#733500'
  secondary-fixed: '#e6e2dc'
  secondary-fixed-dim: '#c9c6c1'
  on-secondary-fixed: '#1c1c18'
  on-secondary-fixed-variant: '#484743'
  tertiary-fixed: '#b1eeed'
  tertiary-fixed-dim: '#95d1d1'
  on-tertiary-fixed: '#002020'
  on-tertiary-fixed-variant: '#074f4f'
  background: '#fcf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e1'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-bold:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 20px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style

The design system is built for an eclectic, community-driven internet radio station. It balances the warmth of a vintage analog radio with the crisp precision of a modern digital streaming platform. The personality is "Refined Eclectic"—organized and clean, but layered with texture and human character.

The design style is **Modern-Tactile**. It utilizes a clean, structural layout reminiscent of a high-end physical tuner, paired with a warm, organic color palette. It avoids the coldness of corporate SaaS by leaning into soft-edged geometry and subtle depth. The visual language should evoke the feeling of a sun-drenched living room filled with vinyl records: inviting, vibrant, and authentic.

## Colors

The palette is inspired by the "Calico" namesake, utilizing organic, warm tones to create an immediate sense of comfort.

- **Primary (Sunset Orange):** Used for key actions, active playing states, and high-energy brand moments.
- **Secondary (Cream Linen):** The primary surface color. It provides a softer, more rhythmic background than pure white, reducing eye strain during long listening sessions.
- **Tertiary (Muted Teal):** An accent for secondary UI elements like tags, categories, or "live" indicators. It provides a cooling contrast to the warm primary tones.
- **Neutral (Charcoal):** Used for primary text and high-contrast iconography. It is never pure black (#000) to maintain the organic, "printed" feel.
- **Status (Calamine):** A soft, desaturated red for errors or critical alerts, keeping with the warm tonal range.

## Typography

This design system uses a two-tier font strategy to balance personality with utility.

- **Headlines:** `Plus Jakarta Sans` is chosen for its friendly, rounded terminals and modern geometric structure. It feels energetic and welcoming. High-level displays use tight tracking and heavy weights to create a "poster" feel.
- **UI & Body:** `Hanken Grotesk` provides a sharp, contemporary counterpoint. It is exceptionally legible at small sizes, making it ideal for tracklists, metadata, and technical radio settings.
- **Editorial Touch:** Use `label-bold` for metadata like "GENRE" or "UP NEXT" to provide a clear hierarchy against the softer headline styles.

## Layout & Spacing

The layout follows a **Fluid-Fixed Hybrid** model. While the overall container can stretch to accommodate widescreen displays, internal content modules (like the player and the schedule) occupy specific grid spans to maintain visual density.

- **Grid:** A 12-column system for desktop, 6-column for tablet, and 2-column for mobile.
- **Rhythm:** Spacing is strictly based on an 8px baseline. Use `lg` (48px) for separating major sections (e.g., Hero Player vs. Recent Playlists) to ensure the UI feels airy and unhurried.
- **Mobile Reflow:** On mobile, the "Now Playing" bar anchors to the bottom with a subtle blur, while the main feed uses a single-column stack with horizontal scrolling "shelves" for categorized music.

## Elevation & Depth

To achieve the modern-tactile feel, this design system uses **Tonal Layers** paired with **Ambient Shadows**.

1.  **Level 0 (Canvas):** The `Secondary` cream color. Flat.
2.  **Level 1 (Modules):** Surface-container white with a very soft, diffused shadow (15% opacity Primary color tint, 20px blur). Used for cards and secondary navigation.
3.  **Level 2 (Interactive):** Elements like "Now Playing" or active modals. These use a slightly more pronounced shadow and a 1px solid stroke in a light neutral tone to give the appearance of physical elevation.
4.  **The "Active" State:** Buttons and active selections should feel "pressed" into the surface using a small inset shadow or a simple color shift, moving away from traditional hover-lift effects to feel more like a physical radio button.

## Shapes

The shape language is consistently **Rounded**. This mirrors the friendly nature of the brand and the "soft" feel of the color palette.

- **Components:** Standard buttons, input fields, and track cards use a 0.5rem (8px) radius.
- **Large Containers:** Hero banners and the main player console use `rounded-xl` (1.5rem) to create a distinct, "appliance-like" silhouette.
- **Media:** Album art and profile pictures should always be rounded; never use sharp corners, as they conflict with the "inviting" brand pillar.

## Components

- **Buttons:** Primary buttons are `Primary Sunset Orange` with white text, using `label-bold` typography. They feature a subtle "squishy" feel—on click, they scale down slightly (98%).
- **The "Live" Chip:** A high-visibility indicator using the `Tertiary Teal` with a small pulsating dot. This is the only animated component allowed to break the static layout.
- **Track Lists:** Use "Zebra" striping with a very faint tint of the primary color for alternating rows. This improves legibility in long playlists without adding heavy borders.
- **Input Fields:** Search bars and newsletter signups use a 1px border of `Neutral` at 20% opacity. When focused, the border transitions to the `Primary` color with a soft glow.
- **The Player Console:** A persistent component. It should feel like a dedicated piece of hardware. Use larger icons (24px+) for Play/Pause and include a progress bar that uses a thick 6px line weight for a bold, tactile look.
- **Cards:** Used for shows and hosts. They should feature heavy bottom-padding for typography, ensuring the host's name and show time are always the focal point below the imagery.